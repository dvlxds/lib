// fetch 封装
let baseUrl = "http://192.168.8.215:8082/api/v1";

let wsurl = "wss://opr.cce.cash/ws";

// wsurl = "ws://192.168.8.215:1223/ws";

// 切换时保留查询参数
const urlParams = new URLSearchParams(window.location.search);
const queryCode = urlParams.get("query_code");

// socketUrl = `${wsurl}/order?query_code=${query_code}`;
let socket;
let data = {};
let setdata = (params) => {
  data = { ...params };
};

let time = 0;
let settime = (params) => {
  time = { ...params };
};

let status = 0;
let setstatus = (params) => {
  status = params;
};

// 翻译
let translate = (params) => {
  // 查询当前路由语言
  const currentPath = window.location.pathname;
  const currentLang = currentPath.split("/")[1];
  console.log("当前路径:",currentLang);
  const transactions = {
    "cn":{
      "发送":"发送",
      "到地址":"到地址：",
      "已复制":"已复制",
      "兑换汇率将在收到<b>1</b>网络确认后固定。":"兑换汇率将在收到<b>1</b>网络确认后固定。",
      "接收地址":"接收地址",
      "固定汇率":"固定汇率",
      "浮动汇率":"浮动汇率",
      "兑换信息":"兑换信息",
      "在区块链上查看":"在区块链上查看",
      "接收时间":"接收时间",
      "阻塞时间":"阻塞时间",
      "发送时间":"发送时间",
      "确认":"确认",
      "金额":"金额",
      "费用":"费用",
      "如果您喜欢 FixedFloat 的体验，请在下面的服务中留下评论。我们感谢您的支持!":"如果您喜欢 FixedFloat 的体验，请在下面的服务中留下评论。我们感谢您的支持！",
      "您的":"您的",
      "已发送":"已发送",
      "有关已发送交易的信息":"有关已发送交易的信息",
      "已接受的交易信息":"已接受的交易信息",
    },
    "en": {
      "发送": "Send",
      "到地址": "To address:",
      "已复制": "Copied",
      "兑换汇率将在收到<b>1</b>网络确认后固定。": "Exchange rate will be fixed after <b>1</b> network confirmation.",
      "接收地址": "Receiving address",
      "固定汇率": "Fixed rate",
      "浮动汇率": "Floating rate",
      "兑换信息": "Exchange information",
      "在区块链上查看": "View on blockchain",
      "接收时间": "Receiving time",
      "阻塞时间": "Block time",
      "发送时间": "Sending time",
      "确认": "Confirmation",
      "金额": "Amount",
      "费用": "Fee",
      "如果您喜欢 FixedFloat 的体验，请在下面的服务中留下评论。我们感谢您的支持!": "If you enjoyed your FixedFloat experience, please leave a review on the services below. We appreciate your support!",
      "您的": "Your",
      "已发送": "Sent",
      "有关已发送交易的信息": "Information about sent transaction",
      "已接受的交易信息": "Accepted transaction information"
    },
    "es": {
      "发送": "Enviar",
      "到地址": "A la dirección:",
      "已复制": "Copiado",
      "兑换汇率将在收到<b>1</b>网络确认后固定。": "El tipo de cambio se fijará después de <b>1</b> confirmación de la red.",
      "接收地址": "Dirección de recepción",
      "固定汇率": "Tipo fijo",
      "浮动汇率": "Tipo variable",
      "兑换信息": "Información del intercambio",
      "在区块链上查看": "Ver en blockchain",
      "接收时间": "Hora de recepción",
      "阻塞时间": "Tiempo de bloque",
      "发送时间": "Hora de envío",
      "确认": "Confirmación",
      "金额": "Cantidad",
      "费用": "Tarifa",
      "如果您喜欢 FixedFloat 的体验，请在下面的服务中留下评论。我们感谢您的支持!": "Si disfrutaste de FixedFloat, deja un comentario en los servicios abajo. ¡Agradecemos tu apoyo!",
      "您的": "Tu",
      "已发送": "Enviado",
      "有关已发送交易的信息": "Información de la transacción enviada",
      "已接受的交易信息": "Información de la transacción aceptada"
    },

    "de": {
      "发送": "Senden",
      "到地址": "An Adresse:",
      "已复制": "Kopiert",
      "兑换汇率将在收到<b>1</b>网络确认后固定。": "Der Wechselkurs wird nach <b>1</b> Netzwerkbestätigung festgelegt.",
      "接收地址": "Empfangsadresse",
      "固定汇率": "Fester Kurs",
      "浮动汇率": "Variabler Kurs",
      "兑换信息": "Umtauschinformation",
      "在区块链上查看": "Auf Blockchain anzeigen",
      "接收时间": "Empfangszeit",
      "阻塞时间": "Blockzeit",
      "发送时间": "Sendezeit",
      "确认": "Bestätigung",
      "金额": "Betrag",
      "费用": "Gebühr",
      "如果您喜欢 FixedFloat 的体验，请在下面的服务中留下评论。我们感谢您的支持!": "Wenn Sie FixedFloat mögen, hinterlassen Sie bitte eine Bewertung auf den folgenden Plattformen. Wir schätzen Ihre Unterstützung!",
      "您的": "Ihr",
      "已发送": "Gesendet",
      "有关已发送交易的信息": "Informationen zur gesendeten Transaktion",
      "已接受的交易信息": "Informationen zur akzeptierten Transaktion"
    },
    "fr": {
      "发送": "Envoyer",
      "到地址": "À l'adresse :",
      "已复制": "Copié",
      "兑换汇率将在收到<b>1</b>网络确认后固定。": "Le taux de change sera fixé après <b>1</b> confirmation réseau.",
      "接收地址": "Adresse de réception",
      "固定汇率": "Taux fixe",
      "浮动汇率": "Taux variable",
      "兑换信息": "Informations d'échange",
      "在区块链上查看": "Voir sur la blockchain",
      "接收时间": "Heure de réception",
      "阻塞时间": "Temps de blocage",
      "发送时间": "Heure d'envoi",
      "确认": "Confirmation",
      "金额": "Montant",
      "费用": "Frais",
      "如果您喜欢 FixedFloat 的体验，请在下面的服务中留下评论。我们感谢您的支持!": "Si vous avez apprécié FixedFloat, laissez un avis sur les services ci-dessous. Nous apprécions votre soutien !",
      "您的": "Votre",
      "已发送": "Envoyé",
      "有关已发送交易的信息": "Informations sur la transaction envoyée",
      "已接受的交易信息": "Informations sur la transaction acceptée"
    },
    "pt": {
      "发送": "Enviar",
      "到地址": "Para endereço:",
      "已复制": "Copiado",
      "兑换汇率将在收到<b>1</b>网络确认后固定。": "A taxa de câmbio será fixada após <b>1</b> confirmação da rede.",
      "接收地址": "Endereço de receção", // 巴西用 "Endereço de recebimento"
      "固定汇率": "Taxa fixa",
      "浮动汇率": "Taxa variável",
      "兑换信息": "Informação de câmbio",
      "在区块链上查看": "Ver na blockchain",
      "接收时间": "Hora de receção", // 巴西用 "Hora de recebimento"
      "阻塞时间": "Tempo de bloco",
      "发送时间": "Hora de envio",
      "确认": "Confirmação",
      "金额": "Montante",
      "费用": "Taxa", // 巴西可用 "Taxa de serviço"
      "如果您喜欢 FixedFloat 的体验，请在下面的服务中留下评论。我们感谢您的支持!": "Se gostou da FixedFloat, deixe uma avaliação nos serviços abaixo. Agradecemos seu apoio!",
      "您的": "Seu", // 正式场合用 "Seu/Sua"
      "已发送": "Enviado",
      "有关已发送交易的信息": "Informação da transação enviada",
      "已接受的交易信息": "Informação da transação aceite" // 巴西用 "aceita"
    },
    "ru": {
      "发送": "Отправить",
      "到地址": "На адрес:",
      "已复制": "Скопировано",
      "兑换汇率将在收到<b>1</b>网络确认后固定。": "Курс обмена будет зафиксирован после <b>1</b> подтверждения сети.",
      "接收地址": "Адрес получения",
      "固定汇率": "Фиксированный курс",
      "浮动汇率": "Плавающий курс",
      "兑换信息": "Информация об обмене",
      "在区块链上查看": "Посмотреть в блокчейне",
      "接收时间": "Время получения",
      "阻塞时间": "Время блокировки",
      "发送时间": "Время отправки",
      "确认": "Подтверждение",
      "金额": "Сумма",
      "费用": "Комиссия",
      "如果您喜欢 FixedFloat 的体验，请在下面的服务中留下评论。我们感谢您的支持!": "Если вам понравился сервис FixedFloat, оставьте отзыв на платформах ниже. Мы ценим вашу поддержку!",
      "您的": "Ваш",
      "已发送": "Отправлено",
      "有关已发送交易的信息": "Информация об отправленной транзакции",
      "已接受的交易信息": "Информация о принятой транзакции"
    },
    "pl": {
      "发送": "Wyślij",
      "到地址": "Na adres:",
      "已复制": "Skopiowano",
      "兑换汇率将在收到<b>1</b>网络确认后固定。": "Kurs wymiany zostanie ustalony po <b>1</b> potwierdzeniu sieci.",
      "接收地址": "Adres odbioru",
      "固定汇率": "Kurs stały",
      "浮动汇率": "Kurs zmienny",
      "兑换信息": "Informacje o wymianie",
      "在区块链上查看": "Zobacz w blockchainie",
      "接收时间": "Czas odbioru",
      "阻塞时间": "Czas blokady",
      "发送时间": "Czas wysyłki",
      "确认": "Potwierdzenie",
      "金额": "Kwota",
      "费用": "Opłata",
      "如果您喜欢 FixedFloat 的体验，请在下面的服务中留下评论。我们感谢您的支持!": "Jeśli podobała Ci się usługa FixedFloat, zostaw opinię na poniższych platformach. Doceniamy Twoje wsparcie!",
      "您的": "Twój", // 正式场合可用 "Pański"
      "已发送": "Wysłano",
      "有关已发送交易的信息": "Informacje o wysłanej transakcji",
      "已接受的交易信息": "Informacje o zaakceptowanej transakcji"
    },
    "nl": {
      "发送": "Verzenden",
      "到地址": "Naar adres:",
      "已复制": "Gekopieerd",
      "兑换汇率将在收到<b>1</b>网络确认后固定。": "De wisselkoers wordt vastgezet na <b>1</b> netwerkbevestiging.",
      "接收地址": "Ontvangstadres",
      "固定汇率": "Vaste koers",
      "浮动汇率": "Variabele koers",
      "兑换信息": "Wisselinformatie",
      "在区块链上查看": "Bekijken op blockchain",
      "接收时间": "Ontvangsttijd",
      "阻塞时间": "Bloktijd",
      "发送时间": "Verzendtijd",
      "确认": "Bevestiging",
      "金额": "Bedrag",
      "费用": "Kosten",
      "如果您喜欢 FixedFloat 的体验，请在下面的服务中留下评论。我们感谢您的支持!": "Als u tevreden bent met FixedFloat, laat dan een beoordeling achter op onderstaande platforms. We waarderen uw steun!",
      "您的": "Uw",
      "已发送": "Verzonden",
      "有关已发送交易的信息": "Informatie over verzonden transactie",
      "已接受的交易信息": "Informatie over geaccepteerde transactie"
    },
    "ua": {
      "发送": "Надіслати",
      "到地址": "На адресу:",
      "已复制": "Скопійовано",
      "兑换汇率将在收到<b>1</b>网络确认后固定。": "Курс обміну буде зафіксовано після <b>1</b> підтвердження мережі.",
      "接收地址": "Адреса отримання",
      "固定汇率": "Фіксований курс",
      "浮动汇率": "Плавучий курс",
      "兑换信息": "Інформація про обмін",
      "在区块链上查看": "Переглянути в блокчейні",
      "接收时间": "Час отримання",
      "阻塞时间": "Час блокування",
      "发送时间": "Час відправки",
      "确认": "Підтвердження",
      "金额": "Сума",
      "费用": "Комісія",
      "如果您喜欢 FixedFloat 的体验，请在下面的服务中留下评论。我们感谢您的支持!": "Якщо вам сподобався сервіс FixedFloat, залиште відгук на платформах нижче. Ми цінуємо вашу підтримку!",
      "您的": "Ваш",
      "已发送": "Надіслано",
      "有关已发送交易的信息": "Інформація про відправлену транзакцію",
      "已接受的交易信息": "Інформація про прийняту транзакцію"
    },
    "tr": {
      "发送": "Gönder",
      "到地址": "Adrese:",
      "已复制": "Kopyalandı",
      "兑换汇率将在收到<b>1</b>网络确认后固定。": "Döviz kuru <b>1</b> ağ onayı alındıktan sonra sabitlenecektir.",
      "接收地址": "Alım adresi",
      "固定汇率": "Sabit kur",
      "浮动汇率": "Değişken kur",
      "兑换信息": "Takas bilgisi",
      "在区块链上查看": "Blockchain'de görüntüle",
      "接收时间": "Alım zamanı",
      "阻塞时间": "Blok süresi",
      "发送时间": "Gönderim zamanı",
      "确认": "Onay",
      "金额": "Tutar",
      "费用": "Ücret",
      "如果您喜欢 FixedFloat 的体验，请在下面的服务中留下评论。我们感谢您的支持!": "FixedFloat deneyimini beğendiyseniz, aşağıdaki platformlarda yorum bırakın. Desteğiniz için teşekkür ederiz!",
      "您的": "Sizin",
      "已发送": "Gönderildi",
      "有关已发送交易的信息": "Gönderilen işlem bilgisi",
      "已接受的交易信息": "Kabul edilen işlem bilgisi"
    },
    "it": {
      "发送": "Invia",
      "到地址": "All'indirizzo:",
      "已复制": "Copiato",
      "兑换汇率将在收到<b>1</b>网络确认后固定。": "Il tasso di cambio sarà fissato dopo <b>1</b> conferma di rete.",
      "接收地址": "Indirizzo di ricezione",
      "固定汇率": "Tasso fisso",
      "浮动汇率": "Tasso variabile",
      "兑换信息": "Informazioni sullo scambio",
      "在区块链上查看": "Visualizza su blockchain",
      "接收时间": "Ora di ricezione",
      "阻塞时间": "Tempo di blocco",
      "发送时间": "Ora di invio",
      "确认": "Conferma",
      "金额": "Importo",
      "费用": "Commissione",
      "如果您喜欢 FixedFloat 的体验，请在下面的服务中留下评论。我们感谢您的支持!": "Se ti è piaciuto FixedFloat, lascia una recensione sui servizi qui sotto. Apprezziamo il tuo supporto!",
      "您的": "Il tuo", // 正式场合用 "Suo"
      "已发送": "Inviato",
      "有关已发送交易的信息": "Informazioni sulla transazione inviata",
      "已接受的交易信息": "Informazioni sulla transazione accettata"
    },
    "ko": {
      "发送": "전송",
      "到地址": "수신 주소:",
      "已复制": "복사됨",
      "兑换汇率将在收到<b>1</b>网络确认后固定。": "환율은 <b>1</b>회의 네트워크 확인 후 고정됩니다.",
      "接收地址": "수신 주소",
      "固定汇率": "고정 환율",
      "浮动汇率": "변동 환율",
      "兑换信息": "환전 정보",
      "在区块链上查看": "블록체인에서 확인",
      "接收时间": "수신 시간",
      "阻塞时间": "블록 시간",
      "发送时间": "전송 시간",
      "确认": "확인",
      "金额": "금액",
      "费用": "수수료",
      "如果您喜欢 FixedFloat 的体验，请在下面的服务中留下评论。我们感谢您的支持!": "FixedFloat 서비스가 마음에 드셨다면 아래 플랫폼에 리뷰를 남겨주세요. 여러분의 지원에 감사드립니다!",
      "您的": "귀하의", // 非正式场合可用"당신의"
      "已发送": "전송 완료",
      "有关已发送交易的信息": "전송된 거래 정보",
      "已接受的交易信息": "승인된 거래 정보"
    },
    "ja": {
        "发送": "送信",
        "到地址": "送付先:",
        "已复制": "コピーしました",
        "兑换汇率将在收到<b>1</b>网络确认后固定。": "為替レートは<b>1</b>回のネットワーク確認後に確定します。",
        "接收地址": "受取アドレス",
        "固定汇率": "固定レート",
        "浮动汇率": "変動レート",
        "兑换信息": "両替情報",
        "在区块链上查看": "ブロックチェーンで確認",
        "接收时间": "受取時間",
        "阻塞时间": "ブロック時間",
        "发送时间": "送信時間",
        "确认": "確認",
        "金额": "金額",
        "费用": "手数料",
        "如果您喜欢 FixedFloat 的体验，请在下面的服务中留下评论。我们感谢您的支持!": "FixedFloatのサービスをご利用いただきありがとうございます。以下のプラットフォームでレビューをお願いします。",
        "您的": "ご利用の", // 或 "あなたの"（非正式）
        "已发送": "送信済み",
        "有关已发送交易的信息": "送信済み取引の情報",
        "已接受的交易信息": "承認済み取引の情報"
      }


  }

  return transactions[currentLang][params]
}

function formatTimestamp(timestamp) {
  if (!timestamp || Number(timestamp) == NaN) {
    console.error("Invalid timestamp:", timestamp);
    return "--";
  }
  const date = new Date(timestamp);

  // 格式化为 MM/DD/YYYY
  const dateStr = date.toLocaleDateString("en-US", {
    month: "2-digit",
    day: "2-digit",
    year: "numeric",
  });

  // 格式化为 HH:MM AM/PM
  const timeStr = date.toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
    hour12: true,
  });

  return `${dateStr} ${timeStr}`;
}

function connectWebSocket(socketUrl) {
  socket = new WebSocket(socketUrl);
  // setsocketinit(socket);
  socket.onopen = () => {
    console.log("连接已建立");
    // let message2:any = { "class": "query_order", "message_id": '12312312',query_code:query_code };
    // socket.send(JSON.stringify(message2));

    // 监听心跳回应
    socket.onmessage = (event) => {
      let message;
      if (!event.data) return;
      message = JSON.parse(event.data);
      const data = message.data;
      console.log(data, "--------");

      let orderData = {
        id: data.query_code,
        token: "vR4GrVlIU82hFxnUVEBWrqxJ9T6GObEvD2ESjgEm",
        email: "asdasdasd",
        isAuth: false,
        // timeStart: 1,
        // timeLeft: data.expire_time,

        timeStart: 101,
        timeLeft: data.expire_at - Date.now() / 1000,

        // 新增
        create_time: data.create_at,
        convert_mode: data.exchange_model,
        finish_time: data.finish_at,
        transfer_time: data.transfer_time,
        order_input: data.order_input,
        order_output: data.order_output,

        //-------
        from: {
          amount: data.odr_volume,
          address: data.address,
          confirm: null,
          tx: null,
          timeBlock: null,
          // 新增
          abbr_name: data.abbr,
          chain_name: data.chain,

          // ------
        },
        to: {
          amount: data.children[0].volume_origin,
          address: data.children[0].address,
          confirm: null,
          tx: null,
          timeBlock: null,

          // 新增
          abbr_name: data.children[0].abbr,
          chain_name: data.children[0].chain,
          // ------
        },
        back: {
          address: "",
          confirm: null,
          tx: null,
          timeBlock: null,
        },
        // status: data.status,
        status: data.status,
        refundonly: false,
        emergency: {
          status: [],
          choice: "NONE",
          repeat: "0",
          // tmpl: F.id("section_emergency").innerHTML,
        },
      };
      initData(orderData);
      const invalidStatuses = [1, 2, 3, 7];
      if (!invalidStatuses.includes(message.data.status)) {
        socket.onclose = null;
        socket.onmessage = null;
        socket.close();
      }
      if (message?.class == "query_order" && message.code == 0) {
        const newItems = message.data.fulls.filter(
          (full) => !message.data.input.some((inp) => inp.txid === full.txid)
        );
        message.data.input = message.data.input.concat(newItems);
        // 设置信息数据
        setdata(message.data);
        if (!time) {
          settime(Math.trunc(message.data.expire_at - Date.now() / 1000));
        }
      }
      if (message?.class == "push_order" && message.code == 0) {
        const newItems = message.data.fulls.filter(
          (full) => !message.data.input.some((inp) => inp.txid === full.txid)
        );
        message.data.input = message.data.input.concat(newItems);
        setdata(message.data);
        if (!time) {
          settime(Math.trunc(message.data.expire_at - Date.now() / 1000));
        }
      }

      if (message.code != 0) {
        // message.error(message.msg);
        console.error("Error:", message.msg);
        // cusMessage({
        //   type: "error",
        //   content: message.msg,
        // });
      }
    };

    // 监听连接关闭事件
    socket.onclose = () => {
      console.log("连接关闭，尝试重连...");
      getOrderInfo()
        .then((result) => {
          if (result.data.expired_status == 0) {
            // navigate("/err");
            console.error("订单已过期或不存在");
          }
          if (result.data.expired_status == 1) {
            setstatus(1);
            orderquery({ query_code: query_code }).then((result) => {
              if (result.code == 0) {
                const newItems = result.data.fulls.filter(
                  (full) =>
                    !result.data.input.some((inp) => inp.txid === full.txid)
                );
                result.data.input = result.data.input.concat(newItems);
                setdata(result.data);
                settime(Math.trunc(result.data.expire_at - Date.now() / 1000));
                const invalidStatuses = [1, 2, 3, 7];
                if (invalidStatuses.includes(result.data.status)) {
                  clearTimeout(heartbeatSeitime);
                  reconnectCount++;
                  const reconnectDelay = Math.pow(2, reconnectCount) * 1000; // 指数退避算法
                  heartbeatSeitime = setTimeout(
                    connectWebSocket,
                    reconnectDelay
                  );
                }
              }
            });
          }
          if (result.data.expired_status == 2) {
            setstatus(2);
          }
          if (result.data.expired_status == 3) {
            setstatus(3);
          }
        })
        .catch(() => {
          // navigate("/err");
        });
    };
  };

  // 监听连接错误事件
  socket.onerror = (error) => {
    console.error("WebSocket 错误:", error);
    orderpreparequery({ query_code })
      .then((result) => {
        if (result.data.expired_status == 0) {
          navigate("/err");
        }
        if (result.data.expired_status == 1) {
          setstatus(1);
          orderquery({ query_code: query_code }).then((result) => {
            if (result.code == 0) {
              const newItems = result.data.fulls.filter(
                (full) =>
                  !result.data.input.some((inp) => inp.txid === full.txid)
              );
              result.data.input = result.data.input.concat(newItems);
              setdata(result.data);
              settime(Math.trunc(result.data.expire_at - Date.now() / 1000));
              const invalidStatuses = [1, 2, 3, 7];
              if (invalidStatuses.includes(result.data.status)) {
                clearTimeout(heartbeatSeitime);
                reconnectCount++;
                const reconnectDelay = Math.pow(2, reconnectCount) * 1000; // 指数退避算法
                heartbeatSeitime = setTimeout(connectWebSocket, reconnectDelay);
              }
            }
          });
        }
        if (result.data.expired_status == 2) {
          setstatus(2);
        }
        if (result.data.expired_status == 3) {
          setstatus(3);
        }
      })
      .catch(() => {
        navigate("/err");
      });
  };
}

let coinComparison = {
  BTC: "BTC",
  BSC: "BNBBEP20",
  ETH: "ETH",
  USDT: "USDTERC20",
  USDTTRC: "USDTTRC20",
  XMR: "XMR",
  ZRX: "ZRX",
  AAVEETH: "AAVE",
  APT: "APT",
  ARB: "ARB",
  AVAX: "AVAX",
  BAT: "BAT",
  BTT: "BTT",
  BTCBSC: "BTCBEP20", // ????
  BTCLN: "BTCLN",
  BCH: "BCH",
  ADA: "ADA",
  LINK: "LINK",
  ATOM: "ATOM",
  DAIBSC: "DAI", // ???
  DAIETH: "DAI", // ???
  DAIMATIC: "DAI", // ???
  DASH: "DASH",
  MANAETH: "MANA", // ???
  DOGE: "DOGE",
  EOS: "EOS",
  ETHARBITRUM: "ETHARBTM", // ???
  ETHBSC: "ETHBEP20", // ???
  ETHOP: "ETHOPTM", // ???
  ETC: "ETC",
  LTC: "LTC",
  MKR: "MKR",
  CAKE: "CAKE",
  USDP: "USDP",
  PEPEETH: "PEPE", // ???
  DOT: "DOT",
  POL: "POL",
  POLETH: "POL", // ------
  XRP: "XRP",
  SHIBBSC: "SHIBBEP20", // ???
  SHIB: "SHIBERC20", // ???
  SOL: "SOL",
  XLM: "XLM",
  SUI: "SUI",
  USDTARBITRUM: "USDTBEP20", // ???
  USDTSOL: "USDTSOL", // ???
  XTZ: "XTZ",
  TON: "TON",
  TRX: "TRX",
  TUSD: "TUSDERC20", // ???
  USDCARBITRUM: "USDCARBTM", // ???
  USDCBSC: "USDCBEP20", // ???
  USDCETH: "USDCERC20", // ???
  USDCMATIC: "USDCPOLYGON", // ???
  USDCSOL: "USDCSOL",
  VET: "VET",
  WBNBBSC: "BNBBEP20", // --???----
  WETHARBITRUM: "WETH", // ????
  ZEC: "ZEC",
};

function fetchApi(url, method, data) {
  let options = {
    method: method,
    headers: {
      "Content-Type": "application/json",
    },
  };

  // 如果是 GET 或 HEAD 请求，将参数附加到 URL
  if (method.toUpperCase() === "GET" || method.toUpperCase() === "HEAD") {
    if (data) {
      const params = new URLSearchParams();
      for (const key in data) {
        if (data[key] !== undefined) {
          params.append(key, data[key]);
        }
      }
      url += (url.includes("?") ? "&" : "?") + params.toString();
    }
  } else {
    // 其他方法可以包含 body
    options.body = JSON.stringify(data);
  }

  return new Promise((resolve, reject) => {
    fetch(baseUrl + url, options)
      .then((res) => resolve(res.json()))
      .catch((err) => reject(err));
  });
}

const getOrderInfo = async () => {
  const qrery = new URLSearchParams(window.location.search);
  const queryCode = qrery.get("query_code");
  const data = await fetchApi("/openapi/order/query", "GET", {
    // ZWU12WC7DFD0
    query_code: queryCode,
  });

  return data;
};

// 修改左侧订单信息
function editLeftOrder(orderData) {
  let order_info = document.querySelector("#order_info_inner");
  // orderData.status = 4;
  let type = "";
  switch (orderData.status) {
    case 1:
      type = "new";
      // 接收时间
      order_info.querySelector(
        "#order_time_tx"
      ).parentElement.parentElement.className = "none";
      // 完成时间
      order_info.querySelector(
        "#order_time_competed"
      ).parentElement.parentElement.className = "none";
      break;
    case 2:
      type = "exchange";
      // 接收时间
      order_info.querySelector(
        "#order_time_tx"
      ).parentElement.parentElement.className = "";
      // 完成时间
      order_info.querySelector(
        "#order_time_competed"
      ).parentElement.parentElement.className = "none";
      break;
    case 3:
      type = "emergency";
      // 接收时间
      order_info.querySelector(
        "#order_time_tx"
      ).parentElement.parentElement.className = "";
      // 完成时间
      order_info.querySelector(
        "#order_time_competed"
      ).parentElement.parentElement.className = "none";
      break;
    case 4:
      type = "done";
      // 接收时间
      order_info.querySelector(
        "#order_time_tx"
      ).parentElement.parentElement.className = "";
      // 完成时间
      order_info.querySelector(
        "#order_time_competed"
      ).parentElement.parentElement.className = "";
      break;
    case 5:
      type = "refund";
      break;
    case 8:
      type = "expired";
      break;
    default:
      type = "unknown";
      break;
  }

  order_info.querySelector(".order-time").className = "order-time " + type;
}

// 步骤条高亮
//  1-待转入 2-已转入 3-兑换中 4-已完成 7-冻结中 8-已过期 9-已废弃
function highlightStep(status) {
  const steps = document.querySelectorAll(".timeline-container ol li");
  // console.log("steps--------", steps);
  switch (status) {
    case 1:
      steps[0].classList.add("active");
      steps[1].classList.remove("active");
      steps[2].classList.remove("active");
      steps[3].classList.remove("active");
      break;
    case 2:
      steps[0].classList.remove("active");
      steps[1].classList.add("active");
      steps[2].classList.remove("active");
      steps[3].classList.remove("active");
      break;
    case 3:
      steps[0].classList.remove("active");
      steps[1].classList.remove("active");
      steps[2].classList.add("active");
      steps[3].classList.remove("active");
      break;
    case 4:
    case 5:
      steps.forEach((step) => step.classList.remove("active"));
      break;
    case 7:
    case 8:
    case 9:
      // 冻结中、已过期、已废弃
      steps.forEach((step) => step.classList.remove("active"));
      steps[0].classList.add("active");
      break;
    default:
      console.warn("未知状态:", status);
  }
}

// 等待存入 步骤1
function orderpreparequery(orderData) {
  // 详情
  const el = document.querySelector(".order-action-details");
  el.innerHTML = `	<div class="order-data-details">
											<div class="order-p-wrap">
												<p class="order-p-amount">${translate("发送")}<b class="order-amount pseudo-hint-blue" data-hint="已复制"
														data-copy="${orderData.from.amount}" data-value="${orderData.from.abbr_name}">${orderData.from.amount} ${orderData.from.abbr_name}</b>${translate('到地址')}</p>
												<p class="order-p-address"><span class="order-address-wrap"><b
															class="order-address order-address-from pseudo-hint-blue"
															data-copy="${orderData.to.address}" data-hint="${translate("已复制")}"
															title="${orderData.to.address}">
                              ${orderData.to.address}
                              
                              <i class="ico copy"></i>
                              </b></span></p>
											</div>
											<p class="order-attention">${translate("兑换汇率将在收到<b>1</b>网络确认后固定。")}</p>
										</div>
										<div class="order-data-destination">
											<p><label>${translate("接收地址")} ${orderData.to.abbr_name}</label><br><span
													class="order-address-destination">${orderData.to.address}</span></p>
										</div>`;

  // 二维码
  document.querySelector("#order_qr").style.display = "block";
}

// 等待确认 步骤2 3
function orderquery(orderData) {
  console.log(orderData, "orderData.createTime");
  const txid =
    orderData.order_input?.length > 0 ? orderData.order_input[0]?.txid : "--";

  if (orderData.status == 2) {
    setTimeout(() => {
      socket.send(
        JSON.stringify({
          class: "confirm_order",
          message_id: "12312312",
          // order_no: order_no,
          query_code: orderData.id,
        })
      );
    }, 6000);
  }
  // 详情
  const el = document.querySelector(".order-action-details");
  el.innerHTML = `
    <div class="order-data-details">
      <h3>${translate("兑换信息")}</h3>
      <ul class="order-details-list clrfix">
        <li class="order-txid"><label>TxID</label>
          <div><span class="pseudo-hint-blue" data-hint="${translate("已复制")}"
              data-copy="${txid}"
              title="${txid}">
              <font>${txid}</font><i
                class="ico copy"></i>
            </span></div>
        </li>
        <li class="view-blockchain"><label>${translate("在区块链上查看")}</label><ins></ins>
          <div><a class="link-explorer-img svgexplorers" rel="noreferrer noopener"
              href="https://tronscan.org/#/transaction/ ${txid}"
              target="_blank" title="Tronscan">
              <img src='../../assets/images/link.svg'></img>
              </a> </div>
        </li>
        <li><label>${translate("接收时间")}</label><ins></ins>
          <div><time timestamp="${formatTimestamp(
            orderData.create_time * 1000
          )}">${formatTimestamp(orderData.create_time * 1000)}</time></div>
        </li>
        <li><label>${translate("阻塞时间")}</label><ins></ins>
          <div><time timestamp="${formatTimestamp(
            orderData.create_time * 1000
          )}">${formatTimestamp(orderData.create_time * 1000)}</time></div>
        </li>
        <li><label>${translate("确认")}</label><ins></ins>
          <div><span id="order_from_tx_confirmations" class="tx-confirm-now">${
            orderData.status == 2 ? 0 : 1
          }</span> / <span
              class="tx-confirm-need">1</span></div>
        </li>
        <li><label>${translate("金额")}</label><ins></ins>
          <div>${orderData.from.amount} ${orderData.from.abbr_name}</div>
        </li>
        <li><label>>${translate('费用')}</label><ins></ins>
          <div> --1.1 TRX</div>
        </li>
      </ul>
    </div>
    <div class="order-data-destination">
      <p><label>${translate('接收地址')} ${orderData.to.abbr_name}</label><br><span
          class="order-address-destination">${orderData.to.address}</span></p>
    </div>
`;

  // 二维码
  document.querySelector("#order_qr").style.display = "none";
}

// 订单完成 步骤4
function ordercompletequery(orderData) {
  const el = document.querySelector(".order-action-details");

  el.innerHTML = `
      <div class="order-done-wrap">
        <div class="order-done-review">
          <h3 class="order-done-title">${translate('您的')} ${orderData.from.abbr_name} (${orderData.from.chain_name}) ${translate('已发送')} </h3>
          <p>${translate('如果您喜欢 FixedFloat 的体验，请在下面的服务中留下评论。我们感谢您的支持!')}</p>
          <div>
            <a class="" target="_blank" rel="noopener noreferrer"
              href="https://www.bestchange.com/fixedfloat-exchanger.html"><i
                class="svgreviews bestchange"></i> <span>Bestchange</span></a>
            <a class="" target="_blank" rel="noopener"
              href="https://www.trustpilot.com/review/fixedfloat.com"><i
                class="svgreviews trustpilot"></i> <span>Trustpilot</span></a>
          </div>
        </div>
        <div class="order-done-ico">
          <img src="/assets/images/background/order_done_robot.svg">
        </div>
      </div>
`;

  // 添加更多信息

  const input =
    orderData.order_input?.length > 0 ? orderData.order_input[0] : {};
  const output =
    orderData.order_output?.length > 0 ? orderData.order_output[0] : {};
  const moreInfo = document.querySelector("#order_details_more");
  moreInfo.innerHTML = `
          <div class="order-details-more-txs">
            <div class="order-details-tx">
              <h3>${translate('有关已发送交易的信息')} </h3>
              <ul class="order-details-list clrfix">
                <li class="order-txid"><label>TxID</label>
                  <div><span class="pseudo-hint-blue" data-hint="${translate('已复制')}"
                      data-copy="${output.txid ?? "--"} ">
                      <font title="${output.txid ?? "--"} ">
                        ${output.txid ?? "--"} </font><i
                        class="ico copy"></i>
                    </span></div>
                </li>
                <li class="view-blockchain"><label>${translate('在区块链上查看')}:</label><ins></ins>
                  <div><a class="link-explorer-img svgexplorers" rel="noreferrer noopener"
                      href="https://tronscan.org/#/transaction/${
                        output.txid ?? "--"
                      } "
                      target="_blank">
                      <img src="../../assets/images/link.svg"></img>
                      </a> </div>
                </li>
                <li><label>${translate("发送时间")}</label><ins></ins>
                  <div><time timestamp="${
                    output.update_time * 1000
                  }"></time>${formatTimestamp(output.update_time * 1000)}</div>
                </li>
                <li><label>${translate("阻塞时间")}</label><ins></ins>
                  <div><time timestamp="${
                    output.update_time * 1000
                  }" id="order_to_tx_timeblock">${formatTimestamp(
    output.update_time * 1000
  )}</time></div>
                </li>
                <li><label>${translate('确认')}</label><ins></ins>
                  <div id="order_to_tx_confirmations">1+</div>
                </li>
                <li><label>${translate('金额')}</label><ins></ins>
                  <div>${output.volume ?? "-"} ${output.abbr_name ?? "-"}</div>
                </li>
                <li><label>${translate('费用')}</label><ins></ins>
                  <div>--0 TRX</div>
                </li>
              </ul>
            </div>
            <div class="order-details-tx">
              <h3>${translate('已接受的交易信息')}</h3>
              <ul class="order-details-list clrfix">
                <li class="order-txid"><label>TxID</label>
                  <div><span class="pseudo-hint-blue" data-hint="${translate('已复制')}"
                      data-copy="${input.txid ?? "--"}"
                      title="${input.txid ?? "--"}">
                      <font>${input.txid ?? "--"}</font><i
                        class="ico copy"></i>
                    </span></div>
                </li>
                <li class="view-blockchain"><label>${translate('在区块链上查看')}</label><ins></ins>
                  <div><a class="link-explorer-img svgexplorers" rel="noreferrer noopener"
                      href="https://tronscan.org/#/transaction/${
                        input.txid ?? "--"
                      }"
                      target="_blank" >
                        <img src="../../assets/images/link.svg"></img>
                      </a> </div>
                </li>
                <li><label>${translate('接收时间')}</label><ins></ins>
                  <div><time timestamp="${
                    input.update_time * 1000
                  }">${formatTimestamp(input.update_time * 1000)}</time></div>
                </li>
                <li><label>${translate('阻塞时间')}</label><ins></ins>
                  <div><time timestamp="${
                    input.update_time * 1000
                  }" id="order_from_tx_timeblock">${formatTimestamp(input.update_time * 1000)}</time></div>
                </li>
                <li><label>${translate('确认')}</label><ins></ins>
                  <div id="order_from_tx_confirmations">1+</div>
                </li>
                <li><label>${translate('金额')}</label><ins></ins>
                  <div>${input.volume ?? '-'}  ${input.abbr_name ?? '-'}</div>
                </li>
                <li><label>${translate('费用')}</label><ins></ins>
                  <div>--1.1 TRX</div>
                </li>
              </ul>
            </div>
          </div>
  
  `;

  moreInfo.classList.remove("none");

  // 二维码
  document.querySelector("#order_qr").style.display = "none";
}

let timerSeitime = null;
// 时间倒计时
function countdownTimer(orderData) {
  if (orderData.status !== 1) {
    if (timerSeitime) {
      clearInterval(timerSeitime);
    }
    return;
  }
  timerSeitime = setInterval(() => {
    if (orderData.timeLeft <= 0) {
      clearInterval(timerSeitime);
      document.querySelector("#order_time").textContent = "00:00:00";
      return;
    }

    // console.log("倒计时", orderData.timeLeft);
    orderData.timeLeft--;
    const hours = String(Math.floor(orderData.timeLeft / 3600)).padStart(
      2,
      "0"
    );
    const minutes = String(
      Math.floor((orderData.timeLeft % 3600) / 60)
    ).padStart(2, "0");
    const seconds = String(parseInt(orderData.timeLeft % 60)).padStart(2, "0");
    document
      .querySelector("#order_time")
      .setAttribute("data-time", `${hours}:${minutes}:${seconds}`);
  }, 1000);
}

function changeStatus(orderData) {
  // 测试
  // orderData.status = 2;
  // 根据订单状态进行不同的处理

  countdownTimer(orderData);

  // 步骤条高亮
  highlightStep(orderData.status);
  // highlightStep(4);

  // 修改左侧订单信息
  editLeftOrder(orderData);
  // 等待存入
  if (orderData.status == 1 || orderData.status == 8) {
    console.log("等待存入");
    orderpreparequery(orderData);
  } else if (orderData.status == 2 || orderData.status == 3) {
    //等待确认
    console.log("等待确认");
    orderquery(orderData);
  } else if (orderData.status == 4 || orderData.status == 5) {
    // 订单完成
    ordercompletequery(orderData);
  }
}

// // 切换时保留查询参数
// const urlParams = new URLSearchParams(window.location.search);
// const queryCode = urlParams.get("query_code");

// 修改所有语言链接
document.querySelectorAll(".menu-focus-opened ul li a").forEach((link) => {
  if (queryCode) {
    const href = new URL(link.href);
    href.searchParams.set("query_code", queryCode);
    link.href = href.toString();
  }
});

// 数据初始化
const initData = (orderData) => {
  // 左下角 订单id
  // document.querySelector('#order_time').setAttribute('data-time',formatTimestamp(orderData.timeLeft * 1000 - Date.now()));
  const orderid = document.querySelector(".pseudo-hint-blue");
  orderid.setAttribute("data-copy", orderData.id);
  orderid.querySelector(".order-id").textContent = orderData.id;
  orderid.querySelector(".order-id").style.fontSize = "12px";
  document.querySelector(".order-type").textContent =
    orderData.convert_mode == "float" ? translate("浮动汇率") : translate("固定汇率");
  // 创建时间
  const createTime = document.querySelector("#order_time_creation");
  createTime.setAttribute("timestamp", orderData.create_time);
  createTime.textContent = formatTimestamp(orderData.create_time * 1000);

  // 接收时间
  const order_time_tx = document.querySelector("#order_time_tx");
  order_time_tx.setAttribute("timestamp", orderData.create_time);
  order_time_tx.textContent = formatTimestamp(orderData.create_time * 1000);

  // 完成时间
  const order_time_competed = document.querySelector("#order_time_competed");
  order_time_competed.setAttribute("timestamp", orderData.finish_time);
  order_time_competed.textContent = formatTimestamp(
    orderData.finish_time * 1000
  );

  // 测试
  // orderData.finish_time = orderData.create_time
  if (orderData.finish_time) {
    const finishTime = document.querySelector("#order_time_competed");
    finishTime.setAttribute("timestamp", orderData.finish_time);
    finishTime.textContent = formatTimestamp(orderData.finish_time * 1000);
    finishTime.parentElement.parentElement.classList.remove("none");
  }

  // 币种信息
  // from
  // 图片
  const fromContainer = document.querySelector(".dir-from .dir-cont");
  fromContainer.setAttribute("data-value", orderData?.from?.abbr_name);
  const classListCon = fromContainer.querySelector(".coin-ico");
  let tempFrom = Array.from(classListCon.classList);
  tempFrom.pop();
  tempFrom.push(orderData?.from?.abbr_name.toLowerCase());
  // classListCon.classList.add(orderData?.from?.abbr_name.toLowerCase());
  classListCon.classList = tempFrom.join(" ");
  // from 数量 和 币种
  document.querySelector(
    "#order_send_value"
  ).textContent = `${orderData.from.amount} ${orderData.from.abbr_name}`;
  // from 地址
  fromContainer.querySelector(".coin-address").textContent =
    orderData.from.address;
  fromContainer
    .querySelector(".coin-address")
    .setAttribute("title", orderData.from.address);
  // to
  // 图片
  const toContainer = document.querySelector(".dir-to .dir-cont");
  toContainer.setAttribute("data-value", orderData?.to?.abbr_name);
  const classListToCon = toContainer.querySelector(".coin-ico");
  let tempTo = Array.from(classListToCon.classList);
  tempTo.pop();
  tempTo.push(orderData?.to?.abbr_name.toLowerCase());
  // classListToCon.classList.add(orderData?.to?.abbr_name.toLowerCase());
  classListToCon.classList = tempTo.join(" ");

  // to 数量 和 币种
  toContainer.querySelector(
    "#order_receive_value"
  ).textContent = `${orderData.to.amount} ${orderData.to.abbr_name}`;

  // to 地址
  toContainer.querySelector(".coin-address").textContent = orderData.to.address;
  toContainer
    .querySelector(".coin-address")
    .setAttribute("title", orderData.to.address);

  // // 二维码 生成 地址
  // new QRCode(document.querySelectorAll(".order-qrcode")[0].querySelector("div"), {
  //   text: orderData.to.address, // 二维码内容
  //   width: 200, // 宽度（像素）
  //   height: 200, // 高度（像素）
  //   colorDark: "#000000", // 二维码颜色
  //   colorLight: "#ffffff", // 背景色
  //   correctLevel: QRCode.CorrectLevel.H, // 容错级别（L/M/Q/H）
  // });

  // // 二维码 生成 金额
  // new QRCode(document.querySelectorAll(".order-qrcode")[1].querySelector("div"), {
  //   text: orderData.from.amount.toString(), // 二维码内容
  //   width: 200, // 宽度（像素）
  //   height: 200, // 高度（像素）
  //   colorDark: "#000000", // 二维码颜色
  //   colorLight: "#ffffff", // 背景色
  //   correctLevel: QRCode.CorrectLevel.H, // 容错级别（L/M/Q/H）
  // });

  // const orderDetails = document.querySelector("order-action-details");

  changeStatus(orderData);
};
(function () {
  // console.log("cn/order/order.js loaded");
  document.addEventListener("DOMContentLoaded", async function () {
    moment.locale("cn");
    APP.highlightingColor("BTC", "AVAX");

    connectWebSocket(`${wsurl}/order?query_code=${queryCode}`);
    const { data } = await getOrderInfo();
    /**
     * {
    "code": 0,
    "msg": "success",
    "data": {
        "abbr_name": "USDT",
        "accept_time": 0,
        "addr_num": 0,
        "address": "TXWdzo18xvgZMQxZ2zr4ogqrCSmbtWWmx4",
        "chain_name": "TRON",
        "convert_mode": "float",
        "create_time": 0,
        "delete_time": 0,
        "expire_time": 0,
        "finish_time": 0,
        "freeze_time": 0,
        "order_children": [
            {
                "abbr_name": "AVAX",
                "address": "0xa97697F04D155184327f87d87384260017B8a9BD",
                "amount": 4998.5,
                "chain_name": "Avalanche(C-Chain)",
                "create_time": 1750733674,
                "finish_time": 0,
                "group_ratio": 1,
                "num": "g7yzC4kX",
                "output": null,
                "price": 19.025884,
                "ratio": 1,
                "status": 1,
                "type": "",
                "volume": 0,
                "volume_origin": 259.9897558
            }
        ],
        "order_fulls": null,
        "order_input": null,
        "order_num": "g7yzC4kX",
        "order_output": null,
        "order_refund": null,
        "order_volume": 5000,
        "price": 0,
        "query_code": "ZWU12WC7DFD0",
        "real_volume": 0,
        "status": 0,
        "transfer_time": 0,
        "type": "TRC20"
    }
}
     */

    let F = UI.func;
    let orderData = {
      id: data.query_code,
      token: "vR4GrVlIU82hFxnUVEBWrqxJ9T6GObEvD2ESjgEm",
      email: "asdasdasd",
      isAuth: false,
      // timeStart: 1,
      // timeLeft: data.expire_time,

      timeStart: 101,
      timeLeft: data.expire_time - Date.now() / 1000,

      // 新增
      create_time: data.create_time,
      convert_mode: data.convert_mode,
      finish_time: data.finish_time,
      transfer_time: data.transfer_time,
      order_input: data.order_input,
      order_output: data.order_output,
      //-------
      from: {
        amount: data.order_volume,
        address: data.address,
        confirm: null,
        tx: null,
        timeBlock: null,
        // 新增
        abbr_name: data.abbr_name,
        chain_name: data.chain_name,
        // ------
      },
      to: {
        amount: data.order_children[0].volume_origin,
        address: data.order_children[0].address,
        confirm: null,
        tx: null,
        timeBlock: null,

        // 新增
        abbr_name: data.order_children[0].abbr_name,
        chain_name: data.order_children[0].chain_name,
        // ------
      },
      back: {
        address: "",
        confirm: null,
        tx: null,
        timeBlock: null,
      },
      status: "NEW",
      status: data.status,
      refundonly: false,
      emergency: {
        status: [],
        choice: "NONE",
        repeat: "0",
        tmpl: F.id("section_emergency").innerHTML,
      },
    };

    // console.log("---------------orderData-----------", orderData);

    let isWidget = false;

    let Notice = {
      input: F.id("notice_email_input"),
      btnwrong: F.id("notice_wrong"),
      switchLayout: function (subscribed) {
        F.togClass("notice_subscribed", "none", !subscribed);
        F.togClass("notice_tosubscribe", "none", subscribed);
      },
      subscribe: function (email) {
        let self = this;
        return APP.api("orderSetEmail", {
          id: orderData.id,
          email: email,
        }).then(function () {
          F.id("notice_email").innerHTML = email;
          self.switchLayout(true);
        });
      },
      init: function () {
        let self = this;
        let emailField = UI.textbox(self.input, {
          addLabel: self.input.getAttribute("data-label"),
          btnclear: true,
          addError: true,
        })
          .input(function (input) {
            F.remClass(input, "error");
          })
          .focus(function (input) {
            F.remClass(input, "error");
          });

        F.bind(self.btnwrong, "click", function (e) {
          e = e || event;
          e.preventDefault();
          self.switchLayout(false);
          return false;
        });

        UI.button("notice_submit").click(function (btn) {
          if (!self.input.value) {
            emailField.error(self.input.getAttribute("data-error-empty"));
            btn.error();
            return;
          }

          Notice.subscribe(self.input.value)
            .then(function () {
              btn.success();
            })
            .catch(function (msg) {
              btn.error();
              if (msg.code == 602) {
                emailField.error(self.input.getAttribute("data-error-invalid"));
              }
            });
        });
      },
      popupEmail: async function () {
        let promise = new Promise(function (resolve, reject) {
          UI.popup({
            bgclose: false,
            html: F.id("popup_email_notification").innerHTML,
            afterRender: function () {
              let popup = this;
              let form = F.id("popup_email_notification_form");
              let emailField = UI.textbox(form.email, {
                addLabel: form.email.getAttribute("data-label"),
                btnclear: true,
                addError: true,
              })
                .input(function (input) {
                  F.remClass(input, "error");
                })
                .focus(function (input) {
                  F.remClass(input, "error");
                });

              let BtnSubmit = UI.button("popup_email_notification_submit", {});

              BtnSubmit.click(function (btn) {
                if (!form.email.value) {
                  emailField.error(form.email.getAttribute("data-error-empty"));
                  btn.error();
                  return;
                }
                Notice.subscribe(form.email.value)
                  .then(function () {
                    btn.success();
                    popup.close();
                    resolve();
                  })
                  .catch(function (msg) {
                    btn.error();
                    if (msg.code == 602) {
                      emailField.error(
                        form.email.getAttribute("data-error-invalid")
                      );
                    }
                  });
              });

              F.bind("popup_email_notification_close", "click", function () {
                if (form.nomore.checked) {
                  APP.setCookie("nomoreNoticeOrder", 1, { expires: 2592000 });
                }
                popup.close();
                resolve();
              });
            },
          }).show();
        });
        return promise;
      },
      warningTag: async function () {
        let promise = new Promise(function (resolve, reject) {
          UI.popup({
            bgclose: false,
            html: F.id("popup_tag_alert").innerHTML,
            afterRender: function () {
              let popup = this;
              let form = F.id("popup_tag_alert_form");

              let BtnSubmit = UI.button("popup_tag_alert_submit", {
                changeAtOnce: false,
              });
              let confirms = form.tag_terms_confirm;
              let nomore = form.tag_terms_nomore;

              F.bind(confirms, "change", function () {
                F.remClass(this.parentNode, "error");
              });

              BtnSubmit.click(function (btn) {
                let error = false;
                for (let i = 0; i < confirms.length; i++) {
                  if (!confirms[i].checked) {
                    F.addClass(confirms[i].parentNode, "error");
                    error = true;
                  }
                }
                if (error) {
                  // btn.error();
                  return;
                }
                if (nomore.checked) {
                  let data = {
                    tz: Intl.DateTimeFormat().resolvedOptions().timeZone,
                    ts: ~~(Date.now() / 1000),
                    tt: Date(),
                  };
                  APP.api("userAcceptTermsTag", data);
                }
                popup.close();
                resolve();
              });
            },
          }).show();
        });
        return promise;
      },
      showPopups: async function () {
        if (
          !isWidget &&
          !orderData.isAuth &&
          !orderData.email &&
          orderData.timeStart < 10 &&
          !APP.getCookie("nomoreNoticeOrder")
        ) {
          await Notice.popupEmail();
        }
        if (F.id("popup_tag_alert") && orderData.timeStart < 10) {
          await Notice.warningTag();
        }
      },
    };

    F.on(document, "click", ".pseudo-hint-blue[data-copy]", function (e) {
      e = e || event;
      e.preventDefault();
      let obj = this;
      F.copy(obj.getAttribute("data-copy"));
      F.addClass(obj, "copied");
      setTimeout(function () {
        F.remClass(obj, "copied");
      }, 500);
    });
    F.on(document, "click", ".copy[data-copy]", function (e) {
      e = e || event;
      e.preventDefault();
      let obj = this;
      F.copy(obj.getAttribute("data-copy"));
      F.addClass(obj, "copied");
      setTimeout(function () {
        F.remClass(obj, "copied");
      }, 500);
    });

    // InitOrder(orderData);
    Notice.init();
    Notice.showPopups();
    if (
      !isWidget &&
      !orderData.isAuth &&
      !orderData.email &&
      orderData.timeStart < 10 &&
      !APP.getCookie("nomoreNoticeOrder")
    ) {
      Notice.popupEmail();
    }
    document.querySelectorAll(".order-qrcode")[0].innerHTML = "";
    document.querySelectorAll(".order-qrcode")[1].innerHTML = "";

    // 二维码 生成 地址
    new QRCode(
      document.querySelectorAll(".order-qrcode")[0],
      {
        text: orderData.to.address, // 二维码内容
        width: 200, // 宽度（像素）
        height: 200, // 高度（像素）
        colorDark: "#000000", // 二维码颜色
        colorLight: "#ffffff", // 背景色
        correctLevel: QRCode.CorrectLevel.H, // 容错级别（L/M/Q/H）
      }
    );

    // 二维码 生成 金额
    new QRCode(
      document.querySelectorAll(".order-qrcode")[1],
      {
        text: orderData.from.amount.toString(), // 二维码内容
        width: 200, // 宽度（像素）
        height: 200, // 高度（像素）
        colorDark: "#000000", // 二维码颜色
        colorLight: "#ffffff", // 背景色
        correctLevel: QRCode.CorrectLevel.H, // 容错级别（L/M/Q/H）
      }
    );

    initData(orderData);
  });
})();
